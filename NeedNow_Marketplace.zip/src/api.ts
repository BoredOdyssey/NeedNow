// src/api.ts - Zero-Dependency REST & Real-Time API Client for NeedNow Marketplace

export const API_BASE = (import.meta as any).env?.VITE_API_URL !== undefined 
  ? (import.meta as any).env.VITE_API_URL 
  : (typeof window !== "undefined" && window.location.hostname ? "" : "http://localhost:5000");

export interface User {
  id: number;
  email: string;
  name: string;
  phone?: string;
  role: "requester" | "provider";
  initials?: string;
  tone?: string;
  rating?: number;
  reviews?: number;
  distance?: number;
  hours?: number;
  price?: number;
  jobsCompleted?: number;
  bio?: string;
  services?: string[];
  portfolio?: string[];
  reviewImage?: string;
  reviewComment?: string;
}

export interface TaskItem {
  id: number;
  title: string;
  category: string;
  customCategory?: string;
  location: string;
  distance?: string;
  budget: string;
  neededBy: string;
  details?: string;
  imageUrl?: string;
  requesterId: number;
  requesterName: string;
  status: "open" | "booked" | "completed" | "cancelled";
  acceptedBidId?: number | null;
  bidsCount?: number;
  bids?: BidItem[];
  acceptedBid?: BidItem | null;
  createdAt?: string;
}

export interface BidItem {
  id: number;
  taskId: number;
  providerId: number;
  name: string;
  initials: string;
  tone: string;
  rating: number;
  reviews: number;
  distance: number;
  hours: number;
  price: number;
  status?: "pending" | "accepted" | "not-selected";
  role?: string;
  reviewImage?: string;
  reviewComment?: string;
  portfolio?: string[];
}

export interface ChatMessage {
  id: number;
  taskId: number;
  senderId: number;
  senderName: string;
  senderRole: "requester" | "provider";
  recipientId?: number | null;
  text: string;
  time?: string;
  mine?: boolean;
  createdAt?: string;
}

export interface MarketplaceStats {
  openRequests: number;
  bidsReceived: number;
  bookedCount: number;
  nearbyRequests: number;
}

class ApiClient {
  private token: string | null = null;

  constructor() {
    if (typeof window !== "undefined") {
      this.token = localStorage.getItem("neednow_auth_token");
    }
  }

  setToken(token: string | null) {
    this.token = token;
    if (typeof window !== "undefined") {
      if (token) {
        localStorage.setItem("neednow_auth_token", token);
      } else {
        localStorage.removeItem("neednow_auth_token");
      }
    }
  }

  getToken() {
    return this.token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      ...(options.headers as Record<string, string> || {})
    };

    if (this.token) {
      headers["Authorization"] = `Bearer ${this.token}`;
    }

    const url = `${API_BASE}${endpoint}`;
    try {
      const response = await fetch(url, { ...options, headers });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data.error || `HTTP ${response.status}: ${response.statusText}`);
      }
      return data as T;
    } catch (err: any) {
      console.warn(`[API] ${endpoint} request failed:`, err.message);
      throw err;
    }
  }

  // Health
  async checkHealth(): Promise<boolean> {
    try {
      const res = await this.request<{ status: string }>("/api/health");
      return res.status === "ok";
    } catch {
      return false;
    }
  }

  // Auth
  async register(params: { name: string; email: string; password: string; phone?: string; role: "requester" | "provider" }) {
    const data = await this.request<{ user: User; token: string }>("/api/auth/register", {
      method: "POST",
      body: JSON.stringify(params)
    });
    this.setToken(data.token);
    return data;
  }

  async login(email: string, password: string) {
    const data = await this.request<{ user: User; token: string }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password })
    });
    this.setToken(data.token);
    return data;
  }

  async getMe(): Promise<User | null> {
    if (!this.token) return null;
    try {
      const res = await this.request<{ user: User }>("/api/auth/me");
      return res.user;
    } catch {
      this.setToken(null);
      return null;
    }
  }

  logout() {
    this.setToken(null);
  }

  // Stats
  async getStats(): Promise<MarketplaceStats> {
    return this.request<MarketplaceStats>("/api/stats");
  }

  // Categories
  async getCategories(): Promise<Array<{ name: string; icon: string; tone: string }>> {
    return this.request("/api/categories");
  }

  // Tasks
  async getTasks(filters?: { category?: string; status?: string; search?: string; requesterId?: number; maxDistance?: number }): Promise<TaskItem[]> {
    const query = new URLSearchParams();
    if (filters?.category) query.append("category", filters.category);
    if (filters?.status) query.append("status", filters.status);
    if (filters?.search) query.append("search", filters.search);
    if (filters?.requesterId) query.append("requesterId", String(filters.requesterId));
    if (filters?.maxDistance) query.append("maxDistance", String(filters.maxDistance));

    const qs = query.toString();
    return this.request<TaskItem[]>(`/api/tasks${qs ? `?${qs}` : ""}`);
  }

  async getTask(id: number): Promise<TaskItem & { bids: BidItem[]; messages: ChatMessage[] }> {
    return this.request(`/api/tasks/${id}`);
  }

  async createTask(task: {
    title: string;
    category?: string;
    customCategory?: string;
    location?: string;
    budget?: string;
    neededBy?: string;
    details?: string;
    imageUrl?: string;
  }): Promise<TaskItem> {
    return this.request<TaskItem>("/api/tasks", {
      method: "POST",
      body: JSON.stringify(task)
    });
  }

  async completeTask(taskId: number, rating: number, comment: string, imageUrl: string) {
    return this.request<{ success: boolean; task: TaskItem; review: any; provider: User }>(`/api/tasks/${taskId}/complete`, {
      method: "POST",
      body: JSON.stringify({ rating, comment, imageUrl })
    });
  }

  // Bids
  async getTaskBids(taskId: number): Promise<BidItem[]> {
    return this.request<BidItem[]>(`/api/tasks/${taskId}/bids`);
  }

  async placeBid(taskId: number, price: number, hours: number): Promise<BidItem> {
    return this.request<BidItem>(`/api/tasks/${taskId}/bids`, {
      method: "POST",
      body: JSON.stringify({ price, hours })
    });
  }

  async acceptBid(bidId: number): Promise<{ success: boolean; bid: BidItem; task: TaskItem }> {
    return this.request(`/api/bids/${bidId}/accept`, {
      method: "POST"
    });
  }

  async getProviderBids(): Promise<Array<BidItem & { taskTitle: string; taskLocation: string; taskBudget: string }>> {
    return this.request("/api/provider/bids");
  }

  // Provider Profiles
  async getProviderProfile(providerId: number): Promise<User & { customerReviews?: any[] }> {
    return this.request(`/api/providers/${providerId}`);
  }

  // Messages / Chat
  async getMessages(taskId: number): Promise<ChatMessage[]> {
    return this.request<ChatMessage[]>(`/api/tasks/${taskId}/messages`);
  }

  async sendMessage(taskId: number, text: string, options?: { recipientId?: number; senderName?: string; senderRole?: "requester" | "provider" }): Promise<ChatMessage> {
    return this.request<ChatMessage>(`/api/tasks/${taskId}/messages`, {
      method: "POST",
      body: JSON.stringify({
        text,
        recipientId: options?.recipientId,
        senderName: options?.senderName,
        senderRole: options?.senderRole
      })
    });
  }

  // Helpline
  async submitHelpline(topic: string, phone?: string): Promise<{ success: boolean; message: string }> {
    return this.request("/api/helpline", {
      method: "POST",
      body: JSON.stringify({ topic, phone })
    });
  }

  // Real-time Event Stream (SSE)
  connectEvents(onEvent: (type: string, data: any) => void): () => void {
    if (typeof window === "undefined" || !("EventSource" in window)) {
      return () => {};
    }

    try {
      const es = new EventSource(`${API_BASE}/api/events`);
      const handlers = ["NEW_TASK", "NEW_BID", "BID_ACCEPTED", "TASK_COMPLETED", "NEW_MESSAGE"];

      handlers.forEach(type => {
        es.addEventListener(type, (e: MessageEvent) => {
          try {
            const data = JSON.parse(e.data);
            onEvent(type, data);
          } catch (err) {
            console.error("Failed to parse SSE payload", err);
          }
        });
      });

      return () => {
        es.close();
      };
    } catch {
      return () => {};
    }
  }
}

export const api = new ApiClient();
